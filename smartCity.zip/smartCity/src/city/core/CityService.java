package city.core;

public abstract class CityService {
    public abstract String getStatusMessage(); // Used polymorphically
}
