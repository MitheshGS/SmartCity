package city.core;

public class PowerPlant {
    private double output;
    private String fuelType;

    public PowerPlant(double output, String fuelType) {
        this.output = output;
        this.fuelType = fuelType;
    }

    public double getOutput() {
        return output;
    }

    public String getFuelType() {
        return fuelType;
    }
}
