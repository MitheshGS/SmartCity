package city.core;

public class Park extends Infrastructure {
    private double area;
    private boolean hasPlayground;
    private int visitors;

    public Park(String id, String location, double area, boolean hasPlayground) {
        super(id, location);
        this.area = area;
        this.hasPlayground = hasPlayground;
    }

    public double getArea() {
        return area;
    }

    public boolean hasPlayground() {
        return hasPlayground;
    }

    public int getVisitors() {
        return visitors;
    }

    public void setVisitors(int visitors) {
        this.visitors = visitors;
    }

    public int calculateGreenScore() {
        int score = 70;
        if (hasPlayground) score += 10;
        if (area > 1500) score += 10;
        return Math.min(score, 100);
    }

    public String getVisitorDensity() {
        if (visitors > 400) return "HIGH";
        else if (visitors > 200) return "MEDIUM";
        else return "LOW";
    }

    @Override
    public String getSummary() {
        return "Park: " + getId() + " at " + getLocation();
    }
}
