package city.services;

import city.core.CityService;
import city.core.WaterTank;

public class WaterService extends CityService{
    private double quality;
    private double level;

    public WaterService(double quality) {
        this.quality = quality;
    }

    public void monitorTank(WaterTank tank) {
        this.level = tank.getCurrentLevel();
    }

    public double getWaterQuality() {
        return quality;
    }

    public String getStatusMessage() {
        if (quality < 50 && level < 3000) return "CRITICAL (Low level & quality)";
        else if (quality < 50) return "POOR QUALITY";
        else if (level < 3000) return "LOW LEVEL";
        else return "NORMAL";
    }

}
