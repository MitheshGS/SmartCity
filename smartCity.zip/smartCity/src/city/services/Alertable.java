package city.services;

interface Alertable {
    String getAlertMessage();
}