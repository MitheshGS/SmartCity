package city.core;

public class WaterTank {
    private double capacity;
    private double currentLevel;

    public WaterTank(double capacity) {
        this.capacity = capacity;
        this.currentLevel = capacity; // initially full
    }

    public void useWater(double amount) {
        currentLevel = Math.max(0, currentLevel - amount);
    }

    public double getCapacity() {
        return capacity;
    }

    public double getCurrentLevel() {
        return currentLevel;
    }

    public double getFillLevel() {
        return (currentLevel / capacity) * 100;
    }
}
