package city.core;

public abstract class Infrastructure {
    private String id;
    private String location;

    public Infrastructure(String id, String location) {
        this.id = id;
        this.location = location;
    }

    public String getId() {
        return id;
    }

    public String getLocation() {
        return location;
    }

    public abstract String getSummary();
}
