package city.services;

import city.core.CityService;
import city.core.PowerPlant;



public class PowerService extends CityService implements Alertable{
    private double demand;
    private double output;
    private double loadPercent;

    public PowerService(double demand) {
        this.demand = demand;
    }

    public void updateOutput(PowerPlant plant) {
        this.output = plant.getOutput();
        this.loadPercent = (output == 0) ? 0 : (demand / output) * 100;
    }

    public double getDemand() {
        return demand;
    }

    public double getLoadPercent() {
        return loadPercent;
    }

    public String getStatusMessage() {
        if (loadPercent > 100) return "UNDER SUPPLY";
        else if (loadPercent < 60) return "EXCESS SUPPLY";
        else return "STABLE";
    }
    
    @Override
    public String getAlertMessage() {
        if (output < demand) {
            return "Demand exceeds supply";
        } else {
            return "No immediate issues";
        }
    }
}
