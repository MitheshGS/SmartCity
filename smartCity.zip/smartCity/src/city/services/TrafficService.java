package city.services;

public class TrafficService {
    private int congestion;

    public TrafficService(int congestion) {
        this.congestion = congestion;
    }

    public String getStatus() {
        if (congestion > 80) return "CONGESTED";
        else if (congestion > 50) return "MODERATE";
        else return "SMOOTH";
    }
}
