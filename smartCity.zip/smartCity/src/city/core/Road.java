package city.core;

public class Road extends Infrastructure {
    private double length;
    private int lanes;
    private int trafficLevel;

    public Road(String id, String location, double length, int lanes) {
        super(id, location);
        this.length = length;
        this.lanes = lanes;
    }

    public void setTrafficLevel(int trafficLevel) {
        this.trafficLevel = trafficLevel;
    }

    public int getTrafficLevel() {
        return trafficLevel;
    }

    public double getLength() {
        return length;
    }

    public int getLanes() {
        return lanes;
    }

    public int calculateCongestion() {
        return trafficLevel;
    }

    public String getAccidentRisk() {
        if (trafficLevel >= 80) return "HIGH";
        else if (trafficLevel >= 50) return "MEDIUM";
        else return "LOW";
    }

    public String getSummary() {
        return "Road: " + getId() + " at " + getLocation();
    }
    

}
