package city.core;

public class CityAsset {
    protected String id;
    protected String location;

    public CityAsset(String id, String location) {
        this.id = id;
        this.location = location;
    }
    public String getId() {
        return id;
    }

    public String getLocation() {
        return location;
    }

    public void displayBasicInfo() {
        System.out.printf("ID: %s | Location: %s%n", id, location);
    }
}
