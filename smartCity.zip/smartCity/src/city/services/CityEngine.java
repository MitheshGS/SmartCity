package city.services;

import city.core.*;
import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CityEngine {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("=================================================");
            System.out.println("             🌆 SMART CITY STATUS REPORT");
            System.out.println("=================================================");
            
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd  hh:mm a");
            System.out.println("\n🕒 Report Generated: " + now.format(formatter));
            System.out.println("👤 Report Viewer: Admin\n");

            // Infrastructure Inputs
            System.out.print("Enter Road ID: ");
            String roadId = scanner.nextLine();
            System.out.print("Enter Road Location: ");
            String roadLoc = scanner.nextLine();
            System.out.print("Enter Road Length (km): ");
            double roadLen = scanner.nextDouble();
            System.out.print("Enter Number of Lanes: ");
            int roadLanes = scanner.nextInt();
            System.out.print("Enter Traffic Level (0-100): ");
            int trafficLevel = scanner.nextInt();
            scanner.nextLine(); // Consume leftover newline

            Road road = new Road(roadId, roadLoc, roadLen, roadLanes);
            road.setTrafficLevel(trafficLevel);

            System.out.print("Enter Park ID: ");
            String parkId = scanner.nextLine();
            System.out.print("Enter Park Location: ");
            String parkLoc = scanner.nextLine();
            System.out.print("Enter Park Area (sqm): ");
            int parkArea = scanner.nextInt();
            System.out.print("Does the park have a playground? (true/false): ");
            boolean hasPlayground = scanner.nextBoolean();
            System.out.print("Enter Number of Visitors: ");
            int visitors = scanner.nextInt();

            Park park = new Park(parkId, parkLoc, parkArea, hasPlayground);
            park.setVisitors(visitors);

            System.out.print("Enter Power Plant Output (MW): ");
            double powerOutput = scanner.nextDouble();
            scanner.nextLine();
            System.out.print("Enter Power Plant Fuel Type: ");
            String fuelType = scanner.nextLine();
            PowerPlant plant = new PowerPlant(powerOutput, fuelType);

            System.out.print("Enter Water Tank Capacity (liters): ");
            double capacity = scanner.nextDouble();
            System.out.print("Enter Water Used (liters): ");
            double used = scanner.nextDouble();
            WaterTank tank = new WaterTank(capacity);
            tank.useWater(used);

            // Services Inputs
            TrafficService traffic = new TrafficService(road.getTrafficLevel());

            System.out.print("Enter Power Demand (MW): ");
            double demand = scanner.nextDouble();
            PowerService power = new PowerService(demand);
            power.updateOutput(plant);

            System.out.print("Enter Water Quality Index (0-100): ");
            double quality = scanner.nextDouble();
            WaterService water = new WaterService(quality);
            water.monitorTank(tank);

            // Environment (static or future input)
            int aqi = 82;
            String weather = "Sunny";
            int temperature = 30;
            int humidity = 40;
            int renewable = 85;
            int greenScore = 78;

            // Output Report
            System.out.println("-------------------------------------------------");
            System.out.println("🏗️  INFRASTRUCTURE OVERVIEW");
            System.out.println("-------------------------------------------------");
            System.out.printf("🏙️ Road ID: %s | Location: %s\n", road.getId(), road.getLocation());
            System.out.printf("   → Length: %.1f km | Lanes: %d | Traffic Level: %d%%\n", road.getLength(), road.getLanes(), road.getTrafficLevel());
            System.out.printf("   🚦 Congestion Index: %s %d%%\n", generateBar(road.calculateCongestion()), road.calculateCongestion());
            System.out.printf("   ⚠️ Accident Risk: %s\n\n", road.getAccidentRisk());

            System.out.printf("🌳 Park ID: %s | Location: %s\n", park.getId(), park.getLocation());
            System.out.printf("   → Area: %.0f sqm | Visitors: %d\n", park.getArea(), park.getVisitors());
            System.out.printf("   🎠 Playground: %s\n", park.hasPlayground() ? "Yes" : "No");
            System.out.printf("   🌿 Green Coverage Score: %d/100\n", park.calculateGreenScore());
            System.out.printf("   👥 Visitor Density: %s\n\n", park.getVisitorDensity());

            System.out.println("-------------------------------------------------");
            System.out.println("🔌 UTILITIES STATUS");
            System.out.println("-------------------------------------------------");
            System.out.println("⚡ Power Plant");
            System.out.printf("   → Output: %.0f MW | Demand: %.0f MW\n", plant.getOutput(), power.getDemand());
            System.out.printf("   🔋 Source: %s\n", plant.getFuelType());
            System.out.printf("   ⚠️ Status: %s\n", power.getStatusMessage());
            System.out.printf("   ⚡ Load %%: %.1f%%\n\n", power.getLoadPercent());

            System.out.println("🚰 Water Tank");
            System.out.printf("   → Capacity: %.0f liters | Current Level: %.0f L\n", tank.getCapacity(), tank.getCurrentLevel());
            System.out.printf("   💧 Quality Index: %.0f/100\n", water.getWaterQuality());
            System.out.printf("   📉 Tank Fill: %s %.0f%%\n", generateTankBar(tank.getFillLevel()), tank.getFillLevel());
            System.out.printf("   ⚠️ Status: %s\n\n", water.getStatusMessage());

            System.out.println("-------------------------------------------------");
            System.out.println("🚨 EMERGENCY ALERTS");
            System.out.println("-------------------------------------------------");
            System.out.println("⚠️ Traffic Alert: High congestion on Downtown Road");
            System.out.println("⚠️ Power Alert: " + power.getAlertMessage());
            System.out.println("⚠️ Water Alert: Poor quality & low reserve\n");

            System.out.println("-------------------------------------------------");
            System.out.println("🌡️ ENVIRONMENTAL METRICS");
            System.out.println("-------------------------------------------------");
            System.out.printf("🌬️ Air Quality Index (AQI): %d (Moderate)\n", aqi);
            System.out.printf("🌦️ Weather: %s | Temp: %d°C | Humidity: %d%%\n", weather, temperature, humidity);
            System.out.printf("🔋 Renewable Energy Usage: %d%%\n", renewable);
            System.out.printf("🌿 City Green Score: %d/100\n\n", greenScore);

            System.out.println("-------------------------------------------------");
            System.out.println("📊 SYSTEM SUMMARY");
            System.out.println("-------------------------------------------------");
            System.out.println("🔋 Power Efficiency: LOW");
            System.out.println("🚰 Water Sustainability: CRITICAL");
            System.out.println("🚦 Traffic Flow: CONGESTED");
            System.out.println("🏞️ Public Spaces Health: GOOD\n");
            System.out.println("🔎 Overall City Health Score: ⚠️ Moderate (57%)");
            System.out.println("📈 Next Forecasted Risks: Power Demand Spike (Evening)\n");

            System.out.println("=================================================");
            System.out.println("📤 TIP: Consider activating Power Saver Mode & ");
            System.out.println("       scheduling water refill operations.");
            System.out.println("=================================================");

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    private static String generateBar(int percent) {
        int blocks = percent / 10;
        return "█".repeat(blocks) + "-".repeat(10 - blocks);
    }

    private static String generateTankBar(double percent) {
        int blocks = (int)(percent / 10);
        return "█".repeat(blocks) + "-".repeat(10 - blocks);
    }
}
